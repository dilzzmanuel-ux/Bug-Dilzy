module.exports = {
  tokens: "8357941989:AAF8XZBzr-h-eHAc0IVyeelHgI8gNtuD90o", 
  owner: "7393949927", 
  port: "9362", // Ini Wajib Jangan Diubah
  ipvps: "https://host.astavvip-tech.xyz" // Jangan Diubah Nanti Eror!!
};